import os
import uuid
from io import BytesIO

from dotenv import load_dotenv
from azure.storage.filedatalake import DataLakeServiceClient

from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SimpleField,
    SearchableField,
    SearchFieldDataType,
)
from azure.search.documents import SearchClient

from pypdf import PdfReader
import docx

load_dotenv()


# ---------------------------------------------------------
# 1. ADLS Client
# ---------------------------------------------------------
def get_adls_client():
    account_name = os.environ["ADLS_ACCOUNT_NAME"]
    account_key = os.environ["ADLS_ACCOUNT_KEY"]

    return DataLakeServiceClient(
        account_url=f"https://{account_name}.dfs.core.windows.net",
        credential=account_key,
    )


# ---------------------------------------------------------
# 2. File Readers
# ---------------------------------------------------------
def read_pdf_bytes(data: bytes) -> str:
    """Extract text from PDF bytes."""
    reader = PdfReader(BytesIO(data))
    text = ""
    for page in reader.pages:
        page_text = page.extract_text() or ""
        text += page_text + "\n"
    return text


def read_docx_bytes(data: bytes) -> str:
    """Extract text from DOCX bytes."""
    file_like = BytesIO(data)
    document = docx.Document(file_like)
    return "\n".join(p.text for p in document.paragraphs)


def read_txt_bytes(data: bytes) -> str:
    """Extract text from TXT bytes."""
    return data.decode("utf-8", errors="ignore")


# ---------------------------------------------------------
# 3. Load documents from ADLS
# ---------------------------------------------------------
def load_docs_from_adls():
    filesystem = os.environ["ADLS_FILESYSTEM"]
    directory = os.environ["ADLS_DIRECTORY"]

    service_client = get_adls_client()
    fs_client = service_client.get_file_system_client(filesystem)

    docs = []

    print(f"Reading files from ADLS path: {filesystem}/{directory}")

    paths = fs_client.get_paths(path=directory)
    for path in paths:
        if path.is_directory:
            continue

        file_client = fs_client.get_file_client(path.name)
        download = file_client.download_file()
        data = download.readall()

        filename = os.path.basename(path.name).lower()

        # Route to correct parser
        if filename.endswith(".pdf"):
            content = read_pdf_bytes(data)
        elif filename.endswith(".docx"):
            content = read_docx_bytes(data)
        elif filename.endswith(".txt"):
            content = read_txt_bytes(data)
        else:
            print(f"Skipping unsupported file: {path.name}")
            continue

        docs.append(
            {
                "id": str(uuid.uuid4()),
                "filename": path.name,
                "content": content,
            }
        )

    return docs


# ---------------------------------------------------------
# 4. Ensure Azure AI Search Index Exists (DROP + RECREATE)
# ---------------------------------------------------------
def ensure_search_index():
    endpoint = os.environ["AZURE_SEARCH_ENDPOINT"]
    api_key = os.environ["AZURE_SEARCH_API_KEY"]
    index_name = os.environ["AZURE_SEARCH_INDEX"]

    credential = AzureKeyCredential(api_key)
    index_client = SearchIndexClient(endpoint=endpoint, credential=credential)

    # Correct schema that matches uploaded documents
    fields = [
        SimpleField(name="id", type=SearchFieldDataType.String, key=True),
        SearchableField(name="filename", type=SearchFieldDataType.String, filterable=True, sortable=True),
        SearchableField(name="content", type=SearchFieldDataType.String),
    ]

    index = SearchIndex(name=index_name, fields=fields)

    # Delete old index to avoid schema mismatch
    try:
        index_client.delete_index(index_name)
        print(f"Deleted existing index '{index_name}'.")
    except Exception:
        print("Index did not exist, creating new one...")

    index_client.create_index(index)
    print(f"Created index '{index_name}' with fields: id, filename, content.")


# ---------------------------------------------------------
# 5. Upload documents to Azure AI Search
# ---------------------------------------------------------
def upload_docs_to_search(docs):
    endpoint = os.environ["AZURE_SEARCH_ENDPOINT"]
    api_key = os.environ["AZURE_SEARCH_API_KEY"]
    index_name = os.environ["AZURE_SEARCH_INDEX"]

    credential = AzureKeyCredential(api_key)
    search_client = SearchClient(endpoint=endpoint, index_name=index_name, credential=credential)

    if not docs:
        print("No documents to upload.")
        return

    print(f"Uploading {len(docs)} documents to Azure AI Search...")

    result = search_client.upload_documents(documents=docs)
    succeeded = sum(1 for r in result if r.succeeded)

    print(f"Uploaded {succeeded}/{len(docs)} documents successfully.")


# ---------------------------------------------------------
# 6. Main Execution
# ---------------------------------------------------------
if __name__ == "__main__":
    print("Loading documents from ADLS...")
    docs = load_docs_from_adls()
    print(f"Loaded {len(docs)} documents.")

    print("Ensuring Azure AI Search index exists...")
    ensure_search_index()

    print("Uploading documents to Azure AI Search...")
    upload_docs_to_search(docs)

    print("Done.")
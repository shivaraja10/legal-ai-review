import os
import asyncio
from dotenv import load_dotenv

from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient

# Azure OpenAI chat client wrapper
from agent_framework.azure import AzureOpenAIChatClient

# Core agent + message/content classes
from agent_framework import ChatAgent, ChatMessage, TextContent

load_dotenv()


# ---------------------------------------------------------
# 1. Create Azure OpenAI Chat Client
# ---------------------------------------------------------
def create_chat_client():
    return AzureOpenAIChatClient(
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
        azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        api_version="2024-10-21",
        deployment_name=os.environ["AZURE_OPENAI_DEPLOYMENT"],
    )


# ---------------------------------------------------------
# 2. Manual RAG using Azure AI Search (with wildcard fallback)
# ---------------------------------------------------------
def retrieve_context(query: str):
    search_client = SearchClient(
        endpoint=os.environ["AZURE_SEARCH_ENDPOINT"],
        index_name=os.environ["AZURE_SEARCH_INDEX"],
        credential=AzureKeyCredential(os.environ["AZURE_SEARCH_API_KEY"]),
    )

    # Terms that indicate vague user intent
    VAGUE_TERMS = {"document", "file", "info", "information", "details", "content"}

    # If the query is vague or too short, use wildcard search
    if any(term in query.lower() for term in VAGUE_TERMS) or len(query.strip()) < 3:
        search_text = "*"
    else:
        search_text = query

    results = search_client.search(
        search_text=search_text,
        top=5,
        include_total_count=True,
        query_type="simple",
        search_mode="any",
    )

    chunks = []
    for r in results:
        content = r.get("content")
        if content:
            chunks.append(content)

    return "\n\n---\n\n".join(chunks)


# ---------------------------------------------------------
# 3. Create Agents
# ---------------------------------------------------------
def create_agents(chat_client):
    def make_agent(system_prompt: str):
        return ChatAgent(
            chat_client=chat_client,
            instructions=system_prompt,
        )

    compliance_agent = make_agent(
        "You are a compliance review agent. Identify compliance risks, "
        "regulatory issues, and policy conflicts based ONLY on the provided context."
    )

    summary_agent = make_agent(
        "You are a legal summarization agent. Provide concise summaries "
        "grounded ONLY on the provided context. Do not invent facts."
    )

    return compliance_agent, summary_agent


# ---------------------------------------------------------
# 4. Console Chat App (Async, manual multi-agent execution)
# ---------------------------------------------------------
async def run_console_app():
    print("Initializing Azure OpenAI chat client...")
    chat_client = create_chat_client()

    print("Creating agents...")
    compliance_agent, summary_agent = create_agents(chat_client)

    print("\n=== Multi-Agent Legal RAG System (Manual RAG + Async Agents) ===")
    print("Ask a question about your legal documents.")
    print("Type 'exit' to quit.\n")

    while True:
        user_input = input("You: ").strip()
        if user_input.lower() in {"exit", "quit"}:
            print("Exiting.")
            break

        if not user_input:
            continue

        print("\n[Retrieving context from Azure AI Search...]\n")
        context = retrieve_context(user_input)

        if not context:
            print("No relevant documents found in Azure AI Search.\n")
            continue

        # Build proper agent_framework message object
        msg = ChatMessage(
            role="user",
            contents=[TextContent(text=f"Context:\n{context}\n\nQuestion:\n{user_input}")]
        )

        # -------------------------------
        # Run Compliance Agent (await)
        # -------------------------------
        compliance_response = await compliance_agent.run(
            messages=[msg]
        )

        # Extract text from AgentRunResponse
        comp_text = compliance_response.messages[-1].contents[0].text

        # -------------------------------
        # Run Summary Agent (await)
        # -------------------------------
        summary_response = await summary_agent.run(
            messages=[msg]
        )

        # Extract text from AgentRunResponse
        sum_text = summary_response.messages[-1].contents[0].text

        print("=== Compliance Findings ===")
        print(comp_text.strip())

        print("\n=== Grounded Summary ===")
        print(sum_text.strip())

        print("\n--------------------------------------\n")


if __name__ == "__main__":
    asyncio.run(run_console_app())